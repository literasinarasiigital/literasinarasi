// src/App.js
import React from "react";
import LiterasiNarasi from "./components/LiterasiNarasi";

function App() {
  return <LiterasiNarasi />;
}

export default App;