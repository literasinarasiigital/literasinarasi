import React, { useState, useEffect } from "react";

export default function AdminNotification() {
  const [tokens, setTokens] = useState([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    fetch("http://localhost:4000/tokens")
      .then(res => res.json())
      .then(setTokens);
  }, []);

  const sendNotification = () => {
    fetch("http://localhost:4000/send-notification", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tokens,
        notification: { title, body }
      }),
    })
      .then(res => res.json())
      .then(data => setStatus(`Success: ${data.success}`))
      .catch(err => setStatus(`Error: ${err.message}`));
  };

  return (
    <div>
      <input placeholder="Judul Notifikasi" value={title} onChange={e => setTitle(e.target.value)} />
      <input placeholder="Isi Notifikasi" value={body} onChange={e => setBody(e.target.value)} />
      <button onClick={sendNotification}>Kirim Notifikasi</button>
      <p>{status}</p>
    </div>
  );
}
