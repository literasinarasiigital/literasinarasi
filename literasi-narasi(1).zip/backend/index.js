const express = require("express");
const cors = require("cors");
const admin = require("firebase-admin");
const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const app = express();
app.use(cors());
app.use(express.json());

app.get("/tokens", async (req, res) => {
  const tokens = [];
  const snapshot = await admin.firestore().collection("fcmTokens").get();
  snapshot.forEach(doc => tokens.push(doc.data().token));
  res.json(tokens);
});

app.post("/send-notification", async (req, res) => {
  const { tokens, notification } = req.body;
  try {
    const message = {
      notification,
      tokens,
    };
    const response = await admin.messaging().sendMulticast(message);
    res.json({ success: response.successCount });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(4000, () => console.log("Backend notif server running on port 4000"));
